
0.9.1 / 2014-05-21
==================

 * add; css property user-select added [gmunkhbaatarmn]
 * fix; cssDefineBlock: do not contain stylusImportList [itchyny]
 * fix; pointer events highlighting
 * mod; make installs slightly easier [dbryand]

0.9.0 / 2014-02-27
==================

 * add; Enable jump to file on abbreviated @import
 * add; broadened defintion of keyword to include [#-]; unnecessarily complained about single-line comments.
 * add; css3 syntax as part of project
 * add; example of require fix
 * add; function interpolations Fixes #7
 * add; the 'Stylus' command (to validate the current file)
 * del; local set overrides
 * fix; braces indenting
 * fix; highlighting variables without $ Closes #22
 * fix; indentation
 * fix; line comments (//).
 * fix; single line comment ignore http://
 * fix; stylus comment after property
 * fix; support space between property value GH #11
 * fix; syntax highlighting for comments
 * fix; syntax highlighting for stylus import/require
 * fix; unsetting main_syntax fixes issues with other plugins
 * mod; Extends highlighted hex colors to include #n and #nn.

0.8.3 / 2011-09-26 
==================

  * Added missing background properties Fixes #5

0.8.2 / 2011-09-01 
==================

  * updated function list
  * removed extra stylus from properties cluster
